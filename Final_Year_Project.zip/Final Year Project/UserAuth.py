from flask import Flask, make_response, render_template, request, redirect, url_for, flash, session
import mysql.connector
import bcrypt
from datetime import datetime, timedelta
import secrets
from flask_mail import Mail, Message
import os
import dotenv
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

# Load environment variables
dotenv.load_dotenv()

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY', 'fallback-secret-key')

# Email Configuration
# Email Configuration
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True  # Use TLS
app.config['MAIL_USE_SSL'] = False  # Don't use SSL
app.config['MAIL_USERNAME'] = 'nexgenbudgets.noreply@gmail.com'  # Your no-reply email
app.config['MAIL_PASSWORD'] = 'zwvg mgpd dncw ybmv'  # The 16-char app password or account password
app.config['MAIL_DEFAULT_SENDER'] = ('NexGen Budgets', 'nexgenbudgets.noreply@gmail.com')

mail = Mail(app)

# Database connection
def get_db():
    try:
        return mysql.connector.connect(
            host=os.getenv('DB_HOST', 'localhost'),  # Default to localhost
            port=int(os.getenv('DB_PORT', 3306)),    # Ensure port is integer
            user=os.getenv('DB_USER', 'root'),      # Default user
            password=os.getenv('DB_PASSWORD', ''),   # Default empty password
            database=os.getenv('DB_NAME', 'nexgen'),# Default database name
            auth_plugin='mysql_native_password',    # Explicit authentication plugin
            use_pure=True                           # Use pure Python implementation
        )
    except mysql.connector.Error as err:
        flash(f"Database connection error: {err}", "error")
        return None

# ------------------- Authentication Routes -------------------
@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['uEmail']
        password = request.form['uPassword']
        ip_address = request.remote_addr
        
        conn = None
        cursor = None
        try:
            conn = get_db()
            if conn is None:
                flash("Database connection failed", "error")
                return redirect(url_for('login'))
            
            cursor = conn.cursor(dictionary=True)
            cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
            user = cursor.fetchone()
            
            if not user:
                flash('⚠️ Account does not exist! Please sign up.', 'error')
                return redirect(url_for('signup', email=email))
            
            if bcrypt.checkpw(password.encode('utf-8'), user['password'].encode('utf-8')):
                cursor.execute("""
                    INSERT INTO login_attempts (user_id, status, ip_address)
                    VALUES (%s, 'success', %s)
                """, (user['id'], ip_address))
                conn.commit()
                
                session['user_id'] = user['id']
                session['logged_in'] = True
                session['email'] = user['email']
                session['full_name'] = user['full_name']
                flash('🎉 Login successful!', 'success')
                return redirect(url_for('dashboard'))
            else:
                cursor.execute("""
                    INSERT INTO login_attempts (user_id, status, ip_address)
                    VALUES (%s, 'failed', %s)
                """, (user['id'], ip_address))
                conn.commit()
                flash('❌ Invalid password!', 'error')
                
        except Exception as e:
            flash(f'⚠️ System error: {str(e)}', 'error')
        finally:
            if conn and conn.is_connected():
                cursor.close()
                conn.close()
    
    return render_template('nexGen.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == "POST":
        data = request.form
        email = data.get("email", "").strip()
        password = data.get("password", "")
        re_password = data.get("re_password", "")
        
        # Basic validation
        if not email or '@' not in email:
            flash("Please enter a valid email address", "error")
            return redirect(url_for('signup'))
        
        # Password validation
        if len(password) < 8:
            flash("Password must be at least 8 characters", "error")
            return redirect(url_for('signup'))
        
        if not any(char.isdigit() for char in password):
            flash("Password must contain at least one number", "error")
            return redirect(url_for('signup'))
            
        if not any(char in '!@#$%^&*(),.?":{}|<>' for char in password):
            flash("Password must contain at least one special character", "error")
            return redirect(url_for('signup'))
            
        if password != re_password:
            flash("Passwords do not match", "error")
            return redirect(url_for('signup'))
        
        conn = None
        cursor = None
        try:
            hashed_pw = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
            conn = get_db()
            if conn is None:
                flash("Database connection failed", "error")
                return redirect(url_for('signup'))
                
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO users (full_name, email, phone, business_name, password, country, state)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """, (
                data.get("full_name", "").strip(),
                email,
                data.get("phone", "").strip(),
                data.get("business_name", "").strip(),
                hashed_pw,
                data.get("country", "").strip(),
                data.get("state", "").strip()
            ))
            conn.commit()
            flash("Account created successfully!", "success")
            return redirect(url_for('login'))
            
        except mysql.connector.IntegrityError:
            flash("Email already exists!", "error")
        except Exception as e:
            flash(f"Error: {str(e)}", "error")
        finally:
            if conn and conn.is_connected():
                cursor.close()
                conn.close()

    return render_template('sign_up.html', email=request.args.get('email', ''))

limiter = Limiter(
    get_remote_address,
    app=app,
    storage_uri="memory://"
)

@app.route('/forgot_password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form.get('email', '').strip()
        
        # Validate email
        if not email or '@' not in email:
            flash("Please enter a valid email address", "error")
            return redirect(url_for('forgot_password'))
        
        conn = None
        cursor = None
        try:
            conn = get_db()
            cursor = conn.cursor(dictionary=True)
            cursor.execute("SELECT id, full_name FROM users WHERE email = %s", (email,))
            user = cursor.fetchone()
            
            if user:
                # Generate secure token
                token = secrets.token_urlsafe(32)
                expires_at = datetime.now() + timedelta(hours=1)
                
                # Store token in database
                cursor.execute("""
                    INSERT INTO password_reset_tokens (user_id, token, expires_at)
                    VALUES (%s, %s, %s)
                """, (user['id'], token, expires_at))
                conn.commit()
                
                # Create reset link
                reset_link = url_for('reset_password', token=token, _external=True)
                
                # Prepare email
                msg = Message(
                    'Password Reset Request',
                    recipients=[email]
                )
                msg.body = f"""Hello {user['full_name']},
                
We received a request to reset your password. Click the link below:
{reset_link}

This link will expire in 1 hour.

If you didn't request this, please ignore this email."""
                
                # Send email
                mail.send(msg)
                
            # Always show success to prevent email enumeration
            flash("If an account exists, you'll receive a reset link shortly.📌Check SPAM folder also", "info")
            return redirect(url_for('forgot_password'))
            
        except Exception as e:
            print(f"Error in password reset: {str(e)}")
            flash("An error occurred. Please try again.", "error")
        finally:
            if conn and conn.is_connected():
                cursor.close()
                conn.close()
    
    return render_template('forgot_password.html')

@app.route('/reset_password', methods=['GET', 'POST'])
def reset_password():
    token = request.args.get('token')
    if not token:
        flash("Invalid reset link", "error")
        return redirect(url_for('forgot_password'))
    
    conn = None
    cursor = None
    try:
        conn = get_db()
        if conn is None:
            flash("Database connection failed", "error")
            return redirect(url_for('forgot_password'))
            
        cursor = conn.cursor(dictionary=True)
        cursor.execute("""
            SELECT user_id FROM password_reset_tokens
            WHERE token = %s AND expires_at > NOW()
        """, (token,))
        valid_token = cursor.fetchone()
        
        if not valid_token:
            flash("Invalid or expired reset link", "error")
            return redirect(url_for('forgot_password'))
        
        if request.method == 'POST':
            new_password = request.form.get('password', '')
            confirm_password = request.form.get('confirm_password', '')
            
            if not new_password or len(new_password) < 8:
                flash("Password must be at least 8 characters", "error")
                return render_template('reset_password.html', token=token)
                
            if new_password != confirm_password:
                flash("Passwords do not match", "error")
                return render_template('reset_password.html', token=token)
                
            hashed_pw = bcrypt.hashpw(new_password.encode('utf-8'), bcrypt.gensalt())
            
            cursor.execute("""
                UPDATE users SET password = %s
                WHERE id = %s
            """, (hashed_pw, valid_token['user_id']))
            
            cursor.execute("DELETE FROM password_reset_tokens WHERE token = %s", (token,))
            conn.commit()
            flash("Password updated successfully! Please login.", "success")
            return redirect(url_for('login'))
        
        return render_template('reset_password.html', token=token)
        
    except Exception as e:
        flash(f"Error: {str(e)}", "error")
        return redirect(url_for('forgot_password'))
    finally:
        if conn and conn.is_connected():
            cursor.close()
            conn.close()

# ------------------- Dashboard Routes -------------------
@app.route('/dashboard')
def dashboard():
    if not session.get('logged_in'):
        flash('🔒 Please login to access dashboard', 'error')
        return redirect(url_for('login'))
    
    conn = None
    cursor = None
    try:
        conn = get_db()
        if conn is None:
            flash("Database connection failed", "error")
            return redirect(url_for('login'))
            
        cursor = conn.cursor(dictionary=True)
        
        # Get login history
        cursor.execute("""
            SELECT attempt_time, status, ip_address 
            FROM login_attempts 
            WHERE user_id = %s 
            ORDER BY attempt_time DESC 
            LIMIT 5
        """, (session['user_id'],))
        login_history = cursor.fetchall()

        # Get user data
        cursor.execute("SELECT * FROM users WHERE id = %s", (session['user_id'],))
        user = cursor.fetchone()
        
        # Get work orders
        cursor.execute("""
            SELECT wo.*, 
                   SUM(CASE WHEN woi.is_expense THEN woi.amount ELSE 0 END) as expenses,
                   SUM(CASE WHEN NOT woi.is_expense THEN woi.amount ELSE 0 END) as income
            FROM work_orders wo
            LEFT JOIN work_order_items woi ON wo.id = woi.work_order_id
            WHERE wo.user_id = %s
            GROUP BY wo.id
            ORDER BY wo.created_at DESC
        """, (session['user_id'],))
        orders = cursor.fetchall()
        
        return render_template('dashboard.html', 
                            user=user, 
                            login_history=login_history,
                            orders=orders)
        
    except Exception as e:
        flash(f'⚠️ Error loading dashboard: {str(e)}', 'error')
        return redirect(url_for('login'))
    finally:
        if conn and conn.is_connected():
            cursor.close()
            conn.close()

@app.route('/login_activity')
def login_activity():
    if not session.get('logged_in'):
        flash('🔒 Please login to access login activity', 'error')
        return redirect(url_for('login'))
    
    conn = None
    cursor = None
    try:
        conn = get_db()
        if conn is None:
            flash("Database connection failed", "error")
            return redirect(url_for('login'))
            
        cursor = conn.cursor(dictionary=True)
        page = request.args.get('page', 1, type=int)
        per_page = 10
        offset = (page - 1) * per_page
        
        cursor.execute("SELECT COUNT(*) as total FROM login_attempts WHERE user_id = %s", (session['user_id'],))
        total_records = cursor.fetchone()['total']
        total_pages = (total_records + per_page - 1) // per_page
        
        cursor.execute("""
            SELECT attempt_time, status, ip_address 
            FROM login_attempts 
            WHERE user_id = %s 
            ORDER BY attempt_time DESC 
            LIMIT %s OFFSET %s
        """, (session['user_id'], per_page, offset))
        login_history = cursor.fetchall()

        cursor.execute("SELECT * FROM users WHERE id = %s", (session['user_id'],))
        user = cursor.fetchone()
        
        return render_template('login_activity.html', 
                            user=user, 
                            login_history=login_history,
                            total_pages=total_pages,
                            current_page=page)
        
    except Exception as e:
        flash(f'⚠️ Error loading login activity: {str(e)}', 'error')
        return redirect(url_for('dashboard'))
    finally:
        if conn and conn.is_connected():
            cursor.close()
            conn.close()

@app.route('/logout')
def logout():
    if 'user_id' in session:
        conn = None
        cursor = None
        try:
            conn = get_db()
            if conn is None:
                flash("Database connection failed", "error")
                return redirect(url_for('login'))
                
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO user_logins (user_id, activity_type)
                VALUES (%s, 'logout')
            """, (session['user_id'],))
            conn.commit()
        except Exception as e:
            print(f"Error logging logout activity: {e}")
        finally:
            if conn and conn.is_connected():
                cursor.close()
                conn.close()
    
    session.clear()
    flash('You have been logged out successfully.', 'info')
    response = redirect(url_for('login'))
    response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, post-check=0, pre-check=0, max-age=0'
    response.headers['Pragma'] = 'no-cache'
    return response

# ------------------- Work Order Routes -------------------
@app.route('/work_orders/<int:order_id>')
def view_work_order(order_id):
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    
    conn = None
    cursor = None
    try:
        conn = get_db()
        if conn is None:
            flash("Database connection failed", "error")
            return redirect(url_for('login'))
            
        cursor = conn.cursor(dictionary=True)
        
        # Get the work order
        cursor.execute("""
            SELECT * FROM work_orders 
            WHERE id = %s AND user_id = %s
        """, (order_id, session['user_id']))
        order = cursor.fetchone()
        
        if not order:
            flash('Work order not found', 'error')
            return redirect(url_for('work_orders'))
        
        # Get items for this work order
        cursor.execute("""
            SELECT *, DATE_FORMAT(date, '%%Y-%%m-%%d') as formatted_date 
            FROM work_order_items
            WHERE work_order_id = %s
            ORDER BY date DESC
        """, (order_id,))
        items = cursor.fetchall()
        
        return render_template('view_work_order.html', 
                            order=order, 
                            items=items)
        
    except Exception as e:
        flash(f'Error loading work order: {str(e)}', 'error')
        return redirect(url_for('work_orders'))
    finally:
        if conn and conn.is_connected():
            cursor.close()
            conn.close()

@app.route('/work_orders')
def work_orders():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    
    conn = None
    cursor = None
    try:
        conn = get_db()
        if conn is None:
            flash("Database connection failed", "error")
            return redirect(url_for('login'))
            
        cursor = conn.cursor(dictionary=True)
        cursor.execute("""
            SELECT wo.*, 
                   SUM(CASE WHEN woi.is_expense THEN woi.amount ELSE 0 END) as expenses,
                   SUM(CASE WHEN NOT woi.is_expense THEN woi.amount ELSE 0 END) as income
            FROM work_orders wo
            LEFT JOIN work_order_items woi ON wo.id = woi.work_order_id
            WHERE wo.user_id = %s
            GROUP BY wo.id
            ORDER BY wo.created_at DESC
        """, (session['user_id'],))
        orders = cursor.fetchall()
        
        response = make_response(render_template('work_orders.html', orders=orders))
        response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, post-check=0, pre-check=0'
        response.headers['Pragma'] = 'no-cache'
        return response
        
    except Exception as e:
        flash(f'Error loading work orders: {str(e)}', 'error')
        return redirect(url_for('dashboard'))
    finally:
        if conn and conn.is_connected():
            cursor.close()
            conn.close()

@app.route('/create_work_order')
def create_work_order():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    return render_template('create_work_order.html')

@app.route('/add_work_order', methods=['POST'])
def add_work_order():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    
    title = request.form.get('title', '').strip()
    status = request.form.get('status', 'Draft')
    
    if not title:
        flash('Title is required', 'error')
        return redirect(url_for('create_work_order'))
    
    if status not in ['Draft', 'Active', 'Completed', 'Archived']:
        flash('Invalid status selected', 'error')
        return redirect(url_for('create_work_order'))
    
    conn = None
    cursor = None
    try:
        conn = get_db()
        if conn is None:
            flash("Database connection failed", "error")
            return redirect(url_for('create_work_order'))
            
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO work_orders 
            (user_id, title, client_name, status)
            VALUES (%s, %s, %s, %s)
        """, (session['user_id'],
             title,
             request.form.get('client_name', '').strip(),
             status))
        conn.commit()
        flash('Work order created successfully!', 'success')
        return redirect(url_for('dashboard'))
        
    except Exception as e:
        if conn:
            conn.rollback()
        flash(f'Error creating work order: {str(e)}', 'error')
        return redirect(url_for('create_work_order'))
    finally:
        if conn and conn.is_connected():
            cursor.close()
            conn.close()

# ------------------- Work Order Items Routes -------------------
@app.route('/work_orders/<int:order_id>/add_item', methods=['GET', 'POST'])
def add_work_order_item(order_id):
    if not session.get('logged_in'):
        return redirect(url_for('login'))

    if request.method == 'POST':
        description = request.form.get('description', '').strip()
        try:
            amount = float(request.form.get('amount', 0))
            if amount <= 0:
                raise ValueError
        except ValueError:
            flash('Please enter a valid positive amount', 'error')
            return redirect(url_for('add_work_order_item', order_id=order_id))
            
        date = request.form.get('date')
        is_expense = 'is_expense' in request.form
        
        if not description:
            flash('Description is required', 'error')
            return redirect(url_for('add_work_order_item', order_id=order_id))

        conn = None
        cursor = None
        try:
            conn = get_db()
            if conn is None:
                flash("Database connection failed", "error")
                return redirect(url_for('add_work_order_item', order_id=order_id))
                
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO work_order_items 
                (work_order_id, description, amount, date, is_expense)
                VALUES (%s, %s, %s, %s, %s)
            """, (order_id, description, amount, date, is_expense))
            conn.commit()
            flash('Item added successfully!', 'success')
            return redirect(url_for('view_work_order', order_id=order_id))
            
        except Exception as e:
            if conn:
                conn.rollback()
            flash(f'Error adding item: {str(e)}', 'error')
        finally:
            if conn and conn.is_connected():
                cursor.close()
                conn.close()

    return render_template('add_work_order_item.html', 
                         order_id=order_id,
                         datetime=datetime)

@app.route('/work_orders/<int:order_id>/delete_item/<int:item_id>')
def delete_work_order_item(order_id, item_id):
    if not session.get('logged_in'):
        return redirect(url_for('login'))

    conn = None
    cursor = None
    try:
        conn = get_db()
        if conn is None:
            flash("Database connection failed", "error")
            return redirect(url_for('view_work_order', order_id=order_id))
            
        cursor = conn.cursor()
        
        # Verify item belongs to user's work order
        cursor.execute("""
            DELETE FROM work_order_items 
            WHERE id = %s AND work_order_id IN (
                SELECT id FROM work_orders WHERE user_id = %s
            )
        """, (item_id, session['user_id']))
        
        if cursor.rowcount == 0:
            flash('Item not found or not authorized', 'error')
        else:
            conn.commit()
            flash('Item deleted successfully', 'success')
            
    except Exception as e:
        if conn:
            conn.rollback()
        flash(f'Error deleting item: {str(e)}', 'error')
    finally:
        if conn and conn.is_connected():
            cursor.close()
            conn.close()
    
    return redirect(url_for('view_work_order', order_id=order_id))

if __name__ == '__main__':
    app.run(debug=os.getenv('FLASK_DEBUG', 'False') == 'True')